from django import forms
from .models import Review
from django.contrib.auth.models import User
ratings=(
    ('1','1'),
    ('2','2'),
    ('3','3'),
    ('4','4'),
    ('5','5'),
)
class ReviewForm(forms.ModelForm):
    rating=forms.ChoiceField(choices=ratings)
    class Meta:
        model=Review
        fields=('rating','review')

# Profile Form
class ProfileForm(forms.ModelForm):
    class Meta:
        model=User
        fields=('first_name','last_name','username','email')

