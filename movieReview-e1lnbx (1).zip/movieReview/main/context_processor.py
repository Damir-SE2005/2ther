from .models import Movie
import datetime
from django.db.models import Avg

def top_movies(request):
    movies=Movie.objects.annotate(total_rating=Avg('review__rating')).order_by('-total_rating')
    return {'top_movies':movies}

def upcoming_movies(request):
    movies=Movie.objects.filter(release_date__gt=datetime.date.today()).order_by('release_date')
    return {'upcoming_movies':movies}