from django.contrib import admin
from .models import *

admin.site.register(Category)
admin.site.register(Celebrity)
admin.site.register(Movie)

class AdminReview(admin.ModelAdmin):
    list_display=('id','movie','rating','review','user')
admin.site.register(Review,AdminReview)
# Movie Image
class AdminMovieImage(admin.ModelAdmin):
    list_display=('id','movie','image')
admin.site.register(MovieImage,AdminMovieImage)
